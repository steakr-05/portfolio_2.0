const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON and incoming URL-encoded form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Setup sessions to remember if you are authorized as admin
app.use(session({
  secret: 'super-secret-key-change-this', // Signs session cookies securely
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false, // Keep false for local HTTP development, set true if deploying on HTTPS
    maxAge: 3600000 // 1 hour session duration before automatic timeout
  }
}));

// Serves the static HTML/CSS files from this directory
app.use(express.static(__dirname));

// The mathematically validated secure hash of the password "AkhtarSecure2026!"
// Change this hash to your own if you generate a custom password.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Nurq1st1k4.";
const HASHED_PASSWORD = bcrypt.hashSync(ADMIN_PASSWORD, 10);// Local storage files (simulating a database directly on your server machine)
const PROJECTS_FILE = path.join(__dirname, 'projects-data.json');
const ROLES_FILE = path.join(__dirname, 'roles-data.json');
const TEXT_EDITS_FILE = path.join(__dirname, 'text-edits.json');

// Safely loads structured database files; defaults to backup values if empty
function readJSON(file, defaultData) {
  if (!fs.existsSync(file)) return defaultData;
  try {
    const raw = fs.readFileSync(file, 'utf8');
    return raw ? JSON.parse(raw) : defaultData;
  } catch (err) {
    console.error(`Error reading ${file}:`, err);
    return defaultData;
  }
}

// Safely writes modified structural data to database files
function writeJSON(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error(`Error writing to ${file}:`, err);
  }
}

/* ============================================================
   SECURE BACKEND API ENDPOINTS
   ============================================================ */

// 1. API: Login Endpoint (Receives plain text password, compares securely on server)
app.post('/api/login', (req, res) => {
    const { password } = req.body;

    if (!password) {
        return res.status(400).json({
            success: false,
            message: "Password is required"
        });
    }

    const isMatch = bcrypt.compareSync(password, HASHED_PASSWORD);

    if (!isMatch) {
        return res.status(401).json({
            success: false,
            message: "Incorrect password"
        });
    }

    req.session.isAdmin = true;

    res.json({
        success: true,
        message: "Authorized successfully"
    });
});

// Middleware: Route guard to lock data save access down to admins only
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) {
    next();
  } else {
    res.status(403).json({ success: false, message: "Access Denied: You must be authorized to save data." });
  }
}

// 2. API: Load Data (Public route so visitors can view your up-to-date data)
app.get('/api/data', (req, res) => {
  res.json({
    projects: readJSON(PROJECTS_FILE, []),
    roles: readJSON(ROLES_FILE, []),
    textEdits: readJSON(TEXT_EDITS_FILE, {})
  });
});

// 3. API: Save Data (Protected route)
app.post('/api/save', requireAdmin, (req, res) => {
  const { projects, roles, textEdits } = req.body;
  
  if (projects) writeJSON(PROJECTS_FILE, projects);
  if (roles) writeJSON(ROLES_FILE, roles);
  if (textEdits) writeJSON(TEXT_EDITS_FILE, textEdits);
  
  res.json({ success: true, message: "Portfolio successfully updated!" });
});

// 4. API: Logout (Clears admin state)
app.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ success: false, message: "Logout failed" });
    }
    res.clearCookie('connect.sid'); // Clears Express Session browser cookie identifier
    res.json({ success: true });
  });
});

// Boot the Server
app.listen(PORT, () => {
  console.log(`\n=============================================================`);
  console.log(`🚀 Secure portfolio server started: http://localhost:${PORT}`);
  console.log(`=============================================================`);
  
  // Security Helper: Display standard generated hash in terminal to confirm system calculation
  try {
    const defaultPassword = 'Nurq1st1k4.';
    const generatedHash = bcrypt.hashSync(defaultPassword, 10);
    console.log(`[Security Helper] Valid hash for default password:`);
    console.log(`  🔑 Password:  ${defaultPassword}`);
    console.log(`  🔒 Hash Code: ${generatedHash}`);
    console.log(`=============================================================\n`);
  } catch (err) {
    console.warn("Could not generate helper logs.");
  }
});